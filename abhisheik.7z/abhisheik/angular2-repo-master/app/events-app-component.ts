import {Component} from '@angular/core'

@Component({
    selector: 'events-app',
    
    template: `
    <pm-products></pm-products>
    
    `
})

export class EventsAppComponent{
     name:  string = "Abhishek";

}